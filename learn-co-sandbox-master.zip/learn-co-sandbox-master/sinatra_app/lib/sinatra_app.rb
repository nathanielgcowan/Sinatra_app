require "sinatra_app/version"

module SinatraApp
  class Error < StandardError; end
  # Your code goes here...
end
